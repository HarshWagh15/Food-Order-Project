import React from 'react'

function Footer() {
    return (
        <>
    <footer>
    <p className="text-center">
        Food Delivery website - 2024-25. All Rights Reserved By Harsh ...
    </p>
    </footer>
        </>
    )
}

export default Footer
